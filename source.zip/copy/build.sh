#!/bin/bash

#set -x
docker-compose down 

cd target/

# store the current dir
CUR_DIR=$(pwd)

build() {
    local i=$1
    echo "";
    echo "\033[33m"+$i+"\033[0m";

    cd "$i";

    echo ${i%?}
    mvn clean verify

    # lets get back to the CUR_DIR
    cd $CUR_DIR
}

for d in */ ; do
    build "$d"
done

docker-compose up --build -d

#sleep 200

#ipaddress=`docker inspect --format '{{ .NetworkSettings.Networks.ters_default.IPAddress }}' ters_ms-bdd-payments-outward-experience_1`
#echo $ipaddress '\t' 'ms-bdd-payments-outward-experience' >> /etc/hosts
